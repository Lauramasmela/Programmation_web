import * as app from './app.js';
window.onload = app.start;