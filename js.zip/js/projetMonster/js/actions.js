import {log, displayStatus} from './ui.js';


 let name = 'nihl';
 let life = 20;
 let money = 2.0;
 let awake = true;


export function get(){
	return this;		
} 

export function init(n, l, m, awake){	
	name=n;
	life=l;
	money=m;
	awake=awake;	
}

export function run(){
	return (event) =>{
		this.life =- 1;
	}

}

export function fight(){
	return (event) => {
		this.life =-  3;
	}

}

export function work(){
	return (event) => {
		this.life =+  3;
	}

}

export function eat(){
	return (event) => {
		this.money =+ -3;
		this.life =+  2;
	}

}


