
export function log(message){
	let msn=message
	let actbox = document.querySelector("#actionbox");
	let t= document.createTextNode(`message : ${msn}`);
	actbox.appendChild(t);
}

export function displayStatus(){
	console.log("hola petardos");
	let ul = document.querySelector("ul#status");
	let li1 = document.createElement("li");
	let mNom= document.createTextNode(`nom: `+ actions.get().name);
	li1.appendChild(mNom);
	let li2 = document.createElement("li");
	let mlife= document.createTextNode(`life: `+ actions.get().life);
	li2.appendChild(mlife);
	let li3 = document.createElement("li");
	let mMoney= document.createTextNode(`money: `+ actions.get().money);
	li3.appendChild(mMoney);
	let li4 = document.createElement("li");
	let mAwake= document.createTextNode(`Awake: `+ actions.get().awake);
	li4.appendChild(mAwake);
}